   <footer role="contentinfo">
        <div class="region region-footer">
    <div class="views-element-container block block-views block-views-blockfooter-content-block-footer-content" id="block-kb2020-views-block-footer-content-block-footer-content">
  
    
      <div><div class="view view-footer-content view-id-footer_content view-display-id-block_footer_content js-view-dom-id-776a76ffa2e498337ea0b29d6711956399a39a9eb27c46ad9e1fc43d38bcb2ef">
  
    
      
      <div class="view-content">
          <div class="views-row"><div class="views-field views-field-field-footer-content"><div class="field-content">  <div class="paragraph paragraph--type--footer-info paragraph--view-mode--default">
          
            <div class="clearfix text-formatted field field--name-field-contact-info field--type-text-long field--label-hidden field__item"><h4>Glia Nova</h4>
<p>Berlini ut. 47-49<br />
1045 Budapest Hungary</p>
<p><a href="mailto:info@glianova.hu">info@glianova.hu</a></p>
</div>
      
      </div>
</div></div></div>

    </div>
  
      
          </div>
</div>

  </div>
<nav role="navigation" aria-labelledby="block-kb2020-mainnavigation-menu" id="block-kb2020-mainnavigation" class="block block-menu navigation menu--main">
            
  <h2 class="visually-hidden" id="block-kb2020-mainnavigation-menu">Main navigation</h2>
  

        
              <ul class="menu">
                    <li class="menu-item">
        <a href="algae-biotech.html" data-drupal-link-system-path="node/4">Algae biotech</a>
              </li>
                <li class="menu-item">
        <a href="blog.html" data-drupal-link-system-path="node/20">News</a>
              </li>
                <li class="menu-item">
        <a href="contact.html" data-drupal-link-system-path="node/9">Contact</a>
              </li>
        </ul>
  


  </nav>
<div class="views-element-container block block-views block-views-blockfooter-content-block-1" id="block-kb2020-privacy-link">
  
    
      <div><div class="view view-footer-content view-id-footer_content view-display-id-block_1 js-view-dom-id-5f3a49b77bbb7875023beb6635f9ffba5a28f1d2979873d4888725d2063367bd">
  
    
      
      <div class="view-content">
          <div class="views-row"><div class="views-field views-field-field-footer-content"><div class="field-content">  <div class="paragraph paragraph--type--footer-info paragraph--view-mode--preview">
          
            <div class="clearfix text-formatted field field--name-field-company-info field--type-text-long field--label-hidden field__item"><h4>Glia Nova</h4>
<p>© Glia Nova.  All rights reserved.</p>
</div>
      
            <div class="field field--name-field-privacy-policy-link field--type-link field--label-hidden field__item"><a href="privacy-policy.html">Privacy policy</a></div>
      
      </div>
</div></div></div>

    </div>
  
      
          </div>
</div>

  </div>

  </div>

    </footer>
  
</div>
  </div>

    <!--
    <script type="application/json" data-drupal-selector="drupal-settings-json">{"path":{"baseUrl":"\/","scriptPath":null,"pathPrefix":"","currentPath":"node\/1","currentPathIsAdmin":false,"isFront":true,"currentLanguage":"en"},"pluralDelimiter":"\u0003","suppressDeprecationErrors":true,"ajaxPageState":{"libraries":"classy\/base,classy\/messages,compony\/global,core\/normalize,eu_cookie_compliance\/eu_cookie_compliance_default,google_analytics\/google_analytics,kb2020\/block--kb2020-entityviewcontent,kb2020\/block-kb2020-main-menu,kb2020\/colorBox,kb2020\/global,kb2020\/node--frontpage--full,kb2020\/node--frontpage--header,kb2020\/owlcarousel,paragraphs\/drupal.paragraphs.unpublished,parallax_bg\/parallax_bg,system\/base,views\/views.module","theme":"kb2020","theme_token":null},"ajaxTrustedUrl":[],"google_analytics":{"account":"UA-159433118-1","trackOutbound":true,"trackMailto":true,"trackTel":true,"trackDownload":true,"trackDownloadExtensions":"7z|aac|arc|arj|asf|asx|avi|bin|csv|doc(x|m)?|dot(x|m)?|exe|flv|gif|gz|gzip|hqx|jar|jpe?g|js|mp(2|3|4|e?g)|mov(ie)?|msi|msp|pdf|phps|png|ppt(x|m)?|pot(x|m)?|pps(x|m)?|ppam|sld(x|m)?|thmx|qtm?|ra(m|r)?|sea|sit|tar|tgz|torrent|txt|wav|wma|wmv|wpd|xls(x|m|b)?|xlt(x|m)|xlam|xml|z|zip","trackColorbox":true},"parallax_bg":[{"selector":"#frontpage-hero","position":"50%","speed":"0.2"}],"eu_cookie_compliance":{"cookie_policy_version":"1.0.0","popup_enabled":true,"popup_agreed_enabled":false,"popup_hide_agreed":false,"popup_clicking_confirmation":false,"popup_scrolling_confirmation":false,"popup_html_info":"\u003Cdiv aria-labelledby=\u0022popup-text\u0022  class=\u0022eu-cookie-compliance-banner eu-cookie-compliance-banner-info eu-cookie-compliance-banner--opt-in\u0022\u003E\n  \u003Cdiv class=\u0022popup-content info eu-cookie-compliance-content\u0022\u003E\n        \u003Cdiv id=\u0022popup-text\u0022 class=\u0022eu-cookie-compliance-message\u0022 role=\u0022document\u0022\u003E\n      \u003Ch2\u003EWe use cookies on this site to enhance your user experience\u003C\/h2\u003E\n\u003Cp\u003EBy clicking the Accept button, you agree to us doing so.\u003C\/p\u003E\n\n          \u003C\/div\u003E\n\n    \n    \u003Cdiv id=\u0022popup-buttons\u0022 class=\u0022eu-cookie-compliance-buttons\u0022\u003E\n            \u003Cbutton type=\u0022button\u0022 class=\u0022agree-button eu-cookie-compliance-secondary-button\u0022\u003EAccept\u003C\/button\u003E\n              \u003Cbutton type=\u0022button\u0022 class=\u0022decline-button eu-cookie-compliance-default-button\u0022\u003ENo, thanks\u003C\/button\u003E\n          \u003C\/div\u003E\n  \u003C\/div\u003E\n\u003C\/div\u003E","use_mobile_message":false,"mobile_popup_html_info":"\u003Cdiv aria-labelledby=\u0022popup-text\u0022  class=\u0022eu-cookie-compliance-banner eu-cookie-compliance-banner-info eu-cookie-compliance-banner--opt-in\u0022\u003E\n  \u003Cdiv class=\u0022popup-content info eu-cookie-compliance-content\u0022\u003E\n        \u003Cdiv id=\u0022popup-text\u0022 class=\u0022eu-cookie-compliance-message\u0022 role=\u0022document\u0022\u003E\n      \n          \u003C\/div\u003E\n\n    \n    \u003Cdiv id=\u0022popup-buttons\u0022 class=\u0022eu-cookie-compliance-buttons\u0022\u003E\n            \u003Cbutton type=\u0022button\u0022 class=\u0022agree-button eu-cookie-compliance-secondary-button\u0022\u003EAccept\u003C\/button\u003E\n              \u003Cbutton type=\u0022button\u0022 class=\u0022decline-button eu-cookie-compliance-default-button\u0022\u003ENo, thanks\u003C\/button\u003E\n          \u003C\/div\u003E\n  \u003C\/div\u003E\n\u003C\/div\u003E","mobile_breakpoint":768,"popup_html_agreed":false,"popup_use_bare_css":false,"popup_height":"auto","popup_width":"100%","popup_delay":1000,"popup_link":"\/privacy-policy","popup_link_new_window":true,"popup_position":false,"fixed_top_position":true,"popup_language":"en","store_consent":false,"better_support_for_screen_readers":false,"cookie_name":"","reload_page":false,"domain":"","domain_all_sites":false,"popup_eu_only":false,"popup_eu_only_js":false,"cookie_lifetime":100,"cookie_session":0,"set_cookie_session_zero_on_disagree":0,"disagree_do_not_show_popup":false,"method":"opt_in","automatic_cookies_removal":true,"allowed_cookies":"","withdraw_markup":"\u003Cbutton type=\u0022button\u0022 class=\u0022eu-cookie-withdraw-tab\u0022\u003EPrivacy settings\u003C\/button\u003E\n\u003Cdiv aria-labelledby=\u0022popup-text\u0022 class=\u0022eu-cookie-withdraw-banner\u0022\u003E\n  \u003Cdiv class=\u0022popup-content info eu-cookie-compliance-content\u0022\u003E\n    \u003Cdiv id=\u0022popup-text\u0022 class=\u0022eu-cookie-compliance-message\u0022 role=\u0022document\u0022\u003E\n      \u003Ch2\u003EWe use cookies on this site to enhance your user experience\u003C\/h2\u003E\n\u003Cp\u003EYou have given your consent for us to set cookies.\u003C\/p\u003E\n\n    \u003C\/div\u003E\n    \u003Cdiv id=\u0022popup-buttons\u0022 class=\u0022eu-cookie-compliance-buttons\u0022\u003E\n      \u003Cbutton type=\u0022button\u0022 class=\u0022eu-cookie-withdraw-button \u0022\u003EWithdraw consent\u003C\/button\u003E\n    \u003C\/div\u003E\n  \u003C\/div\u003E\n\u003C\/div\u003E","withdraw_enabled":false,"reload_options":0,"reload_routes_list":"","withdraw_button_on_info_popup":false,"cookie_categories":[],"cookie_categories_details":[],"enable_save_preferences_button":true,"cookie_value_disagreed":"0","cookie_value_agreed_show_thank_you":"1","cookie_value_agreed":"2","containing_element":"body","settings_tab_enabled":false,"olivero_primary_button_classes":"","olivero_secondary_button_classes":"","close_button_action":"close_banner","open_by_default":true,"modules_allow_popup":true,"hide_the_banner":false,"geoip_match":true},"user":{"uid":0,"permissionsHash":"5e8fe2711c6c825867815addfaae7575c9a7820e603fbd7d1726843667d192bd"}}</script>
<script src="http://kaapabiotech.com/core/assets/vendor/jquery/jquery.min.js?v=3.7.0"></script>
<script src="http://kaapabiotech.com/core/assets/vendor/once/once.min.js?v=1.0.1"></script>
<script src="http://kaapabiotech.com/core/misc/drupalSettingsLoader.js?v=10.1.6"></script>
<script src="http://kaapabiotech.com/core/misc/drupal.js?v=10.1.6"></script>
<script src="http://kaapabiotech.com/core/misc/drupal.init.js?v=10.1.6"></script>
<script src="http://kaapabiotech.com/core/assets/vendor/tabbable/index.umd.min.js?v=6.1.2"></script>
<script src="modules/contrib/google_analytics/js/google_analytics.js%3Fv=10.1.6"></script>
<script src="libraries/jquery.parallax/jquery.parallax.js%3Fs40twd"></script>
<script src="libraries/jquery.localScroll/jquery.localScroll.min.js%3Fs40twd"></script>
<script src="libraries/jquery.scrollTo/jquery.scrollTo.min.js%3Fs40twd"></script>
<script src="modules/custom/parallax_bg/assets/js/parallax_bg.js%3Fs40twd"></script>
<script src="http://kaapabiotech.com/core/misc/progress.js?v=10.1.6"></script>
<script src="http://kaapabiotech.com/core/assets/vendor/loadjs/loadjs.min.js?v=4.2.0"></script>
<script src="http://kaapabiotech.com/core/misc/debounce.js?v=10.1.6"></script>
<script src="http://kaapabiotech.com/core/misc/announce.js?v=10.1.6"></script>
<script src="http://kaapabiotech.com/core/misc/message.js?v=10.1.6"></script>
<script src="http://kaapabiotech.com/core/misc/ajax.js?v=10.1.6"></script>
<script src="themes/contrib/stable/js/ajax.js%3Fv=10.1.6"></script>
<script src="themes/contrib/compony/components/_global/dist/script.js%3Fv=10.1.6"></script>
<script src="themes/custom/kb2020/components/_global/dist/script.js%3Fv=10.1.6"></script>
<script src="libraries/OwlCarousel2/owl.carousel.min.js%3Fv=10.1.6"></script>
<script src="libraries/colorbox/jquery.colorbox-min.js%3Fv=10.1.6"></script>
<script src="http://kaapabiotech.com/core/assets/vendor/js-cookie/js.cookie.min.js?v=3.0.5"></script>
<script src="modules/contrib/eu_cookie_compliance/js/eu_cookie_compliance.min.js%3Fv=10.1.6" defer></script>
<script src="themes/custom/kb2020/components/block/block-kb2020-main-menu/dist/block-kb2020-menu.js%3Fv=10.1.6"></script>

--> 

  </body>
</html>