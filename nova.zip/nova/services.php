
<?php	include "header.php"; //--header content  

?>


  

  <?php	include "footer.php"; //--footer content  

?>
  
  