
<?php	include "header.php"; //--header content  

?>

 

  

  <main role="main">
    <a id="main-content" tabindex="-1"></a>
    <div class="layout-content">
        <div class="region region-content">
    <div id="block-kb2020-page-title" class="block block-core block-page-title-block">
  
    
      
  <h1 class="page-title"><span property="schema:name" class="field field--name-title field--type-string field--label-hidden">News</span>
</h1>


  </div>
<div id="block-kb2020-content" class="block block-system block-system-main-block">
  
    
      
<article data-history-node-id="20" about="/blog" typeof="schema:WebPage" class="node node--type-page">
  <div>
    
  </div>
</article>
  </div>
<div class="views-element-container block block-views block-views-blockmedia-articles-all-articles" id="block-kb2020-views-block-media-articles-all-articles">
  
    
      <div><div class="view view-media-articles view-id-media_articles view-display-id-all_articles js-view-dom-id-4461880630f516763bf51a64667bedb0470d4b345e506067ef116bad9a5c34bd">
  
    
      
      <div class="view-content">
          <div class="views-row">
<a href="media/press-release/applied-food-sciences-and-kaapa-biotech-expand-partnership-new-state-art.html">
  <article data-history-node-id="63" about="/media/press-release/applied-food-sciences-and-kaapa-biotech-expand-partnership-new-state-art" typeof="schema:Article" class="node node--type-article-highlight bg-76b8d5" style="background-image: linear-gradient(180deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0) 55%, #76b8d5 75%), url(sites/default/files/styles/media_highlight/public/2024-09/kaapa-factory.jpg%3Fitok=39dVj67V); background-color: #76b8d5">
    <div class="metadata-container">
      <div class="metadata">
        
            <div class="field field--name-field-article-type field--type-list-string field--label-hidden field__item">Press release</div>
       | <time datetime="2024-09-25T07:00:00Z" class="datetime">25.9.2024</time>

         <h3>Applied Food Sciences and KÄÄPÄ Biotech Expand Partnership with New State-of-the-Art Cultivation Facility</h3>
      </div>
    </div>
  </article>
</a></div>
    <div class="views-row">
<a href="media/blog/kaapa-biotech-oy-has-successfully-concluded-their-food-safety-system-certification-fssc.html">
  <article data-history-node-id="62" about="/media/blog/kaapa-biotech-oy-has-successfully-concluded-their-food-safety-system-certification-fssc" typeof="schema:Article" class="node node--type-article-highlight bg-1a363e" style="background-image: linear-gradient(180deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0) 55%, #1a363e 75%), url(sites/default/files/styles/media_highlight/public/2023-03/fssc-22000_0.jpg%3Fitok=2R9acp5u); background-color: #1a363e">
    <div class="metadata-container">
      <div class="metadata">
        
            <div class="field field--name-field-article-type field--type-list-string field--label-hidden field__item">Blog</div>
       | <time datetime="2023-03-23T15:00:00Z" class="datetime">23.3.2023</time>

         <h3>Kääpä Biotech Oy has successfully concluded their Food Safety System Certification (FSSC 22000) project</h3>
      </div>
    </div>
  </article>
</a></div>
    <div class="views-row">
<a href="media/news/new-york-times-mushrooms-ingredient-year.html">
  <article data-history-node-id="54" about="/media/news/new-york-times-mushrooms-ingredient-year" typeof="schema:Article" class="node node--type-article-highlight bg-edf1f2" style="background-image: linear-gradient(180deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0) 55%, #edf1f2 75%), url(sites/default/files/styles/media_highlight/public/2022-03/shiitake_web_0.jpg%3Fitok=EiiV0SPx); background-color: #edf1f2">
    <div class="metadata-container">
      <div class="metadata">
        
            <div class="field field--name-field-article-type field--type-list-string field--label-hidden field__item">News</div>
       | <time datetime="2022-03-10T12:52:42Z" class="datetime">10.3.2022</time>

         <h3>The New York Times: Mushrooms, the ingredient of the year </h3>
      </div>
    </div>
  </article>
</a></div>
    <div class="views-row">
<a href="media/news/nutraingredients-2021-start-award-winner-kaapa-biotech-our-passion-led-win.html">
  <article data-history-node-id="53" about="/media/news/nutraingredients-2021-start-award-winner-kaapa-biotech-our-passion-led-win" typeof="schema:Article" class="node node--type-article-highlight bg-edf1f2" style="background-image: linear-gradient(180deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0) 55%, #edf1f2 75%), url(sites/default/files/styles/media_highlight/public/2022-02/16._start-up_award_blog.png%3Fitok=oBWA_O56); background-color: #edf1f2">
    <div class="metadata-container">
      <div class="metadata">
        
            <div class="field field--name-field-article-type field--type-list-string field--label-hidden field__item">News</div>
       | <time datetime="2021-12-20T11:50:24Z" class="datetime">20.12.2021</time>

         <h3>NutraIngredients 2021 Start-up Award winner KÄÄPÄ Biotech: ‘Our passion led to the win!’</h3>
      </div>
    </div>
  </article>
</a></div>
    <div class="views-row">
<a href="media/news/fungi-supports-biodiversity-and-richness-microbiota-garden.html">
  <article data-history-node-id="50" about="/media/news/fungi-supports-biodiversity-and-richness-microbiota-garden" typeof="schema:Article" class="node node--type-article-highlight bg-1a363e" style="background-image: linear-gradient(180deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0) 55%, #1a363e 75%), url(sites/default/files/styles/media_highlight/public/2021-10/img-20210422-wa0028_0.jpg%3Fitok=XSD2hV7V); background-color: #1a363e">
    <div class="metadata-container">
      <div class="metadata">
        
            <div class="field field--name-field-article-type field--type-list-string field--label-hidden field__item">News</div>
       | <time datetime="2021-10-12T13:11:21Z" class="datetime">12.10.2021</time>

         <h3>Fungi supports the biodiversity and richness of the microbiota in the garden</h3>
      </div>
    </div>
  </article>
</a></div>
    <div class="views-row">
<a href="media/blog/kaapa-biotech-sponsors-international-society-mushroom-science-e-congress-2021.html">
  <article data-history-node-id="48" about="/media/blog/kaapa-biotech-sponsors-international-society-mushroom-science-e-congress-2021" typeof="schema:Article" class="node node--type-article-highlight bg-1a363e" style="background-image: linear-gradient(180deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0) 55%, #1a363e 75%), url(sites/default/files/styles/media_highlight/public/2021-09/isms_highlight_image.jpg%3Fitok=TAwHZHWQ); background-color: #1a363e">
    <div class="metadata-container">
      <div class="metadata">
        
            <div class="field field--name-field-article-type field--type-list-string field--label-hidden field__item">Blog</div>
       | <time datetime="2021-09-13T10:45:54Z" class="datetime">13.9.2021</time>

         <h3>KÄÄPÄ Biotech sponsors the International Society for Mushroom Science e-Congress 2021</h3>
      </div>
    </div>
  </article>
</a></div>
    <div class="views-row">
<a href="media/press-release/booming-demand-nordic-mushrooms-product-line-kaapa-biotech-announces-series.html">
  <article data-history-node-id="49" about="/media/press-release/booming-demand-nordic-mushrooms-product-line-kaapa-biotech-announces-series" typeof="schema:Article" class="node node--type-article-highlight bg-1a363e" style="background-image: linear-gradient(180deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0) 55%, #1a363e 75%), url(sites/default/files/styles/media_highlight/public/2021-09/rei.jpg%3Fitok=WccgXG34); background-color: #1a363e">
    <div class="metadata-container">
      <div class="metadata">
        
            <div class="field field--name-field-article-type field--type-list-string field--label-hidden field__item">Press release</div>
       | <time datetime="2021-09-09T07:00:14Z" class="datetime">9.9.2021</time>

         <h3>Booming demand on Nordic Mushrooms product line  -  KÄÄPÄ Biotech announces Series A investment round </h3>
      </div>
    </div>
  </article>
</a></div>
    <div class="views-row">
<a href="media/press-release/kaapa-biotech-has-won-start-award-nutraingredients-awards-2021.html">
  <article data-history-node-id="39" about="/media/press-release/kaapa-biotech-has-won-start-award-nutraingredients-awards-2021" typeof="schema:Article" class="node node--type-article-highlight bg-1a363e" style="background-image: linear-gradient(180deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0) 55%, #1a363e 75%), url(sites/default/files/styles/media_highlight/public/2021-06/highlight_image_website.png%3Fitok=oCTsbQaO); background-color: #1a363e">
    <div class="metadata-container">
      <div class="metadata">
        
            <div class="field field--name-field-article-type field--type-list-string field--label-hidden field__item">Press release</div>
       | <time datetime="2021-05-12T07:00:00Z" class="datetime">12.5.2021</time>

         <h3>KÄÄPÄ Biotech has won the Start-up Award in the NutraIngredients Awards 2021</h3>
      </div>
    </div>
  </article>
</a></div>
    <div class="views-row">
<a href="media/news/ultrasonic-assisted-extraction-offers-groundbreaking-benefits.html">
  <article data-history-node-id="45" about="/media/news/ultrasonic-assisted-extraction-offers-groundbreaking-benefits" typeof="schema:Article" class="node node--type-article-highlight bg-1a363e" style="background-image: linear-gradient(180deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0) 55%, #1a363e 75%), url(sites/default/files/styles/media_highlight/public/2021-07/extraction_0.jpg%3Fitok=-DSaVJKw); background-color: #1a363e">
    <div class="metadata-container">
      <div class="metadata">
        
            <div class="field field--name-field-article-type field--type-list-string field--label-hidden field__item">News</div>
       | <time datetime="2020-11-18T20:57:48Z" class="datetime">18.11.2020</time>

         <h3>Ultrasonic-assisted extraction offers groundbreaking benefits</h3>
      </div>
    </div>
  </article>
</a></div>
    <div class="views-row">
<a href="media/news/kaapa-biotech-becomes-europes-biggest-medicinal-mushroom-supplier.html">
  <article data-history-node-id="38" about="/media/news/kaapa-biotech-becomes-europes-biggest-medicinal-mushroom-supplier" typeof="schema:Article" class="node node--type-article-highlight bg-1a363e" style="background-image: linear-gradient(180deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0) 55%, #1a363e 75%), url(sites/default/files/styles/media_highlight/public/2021-06/kb.png%3Fitok=UBb6NlFP); background-color: #1a363e">
    <div class="metadata-container">
      <div class="metadata">
        
            <div class="field field--name-field-article-type field--type-list-string field--label-hidden field__item">News</div>
       | <time datetime="2020-11-16T08:00:00Z" class="datetime">16.11.2020</time>

         <h3>KÄÄPÄ Biotech becomes Europe&#039;s biggest medicinal mushroom supplier</h3>
      </div>
    </div>
  </article>
</a></div>
    <div class="views-row">
<a href="media/press-release/kaapa-biotech-signs-distribution-agreement-nutralliance-north-america.html">
  <article data-history-node-id="37" about="/media/press-release/kaapa-biotech-signs-distribution-agreement-nutralliance-north-america" typeof="schema:Article" class="node node--type-article-highlight bg-1a363e" style="background-image: linear-gradient(180deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0) 55%, #1a363e 75%), url(sites/default/files/styles/media_highlight/public/2021-06/blog_highlight_image_template.png%3Fitok=HZ-XRQJj); background-color: #1a363e">
    <div class="metadata-container">
      <div class="metadata">
        
            <div class="field field--name-field-article-type field--type-list-string field--label-hidden field__item">Press release</div>
       | <time datetime="2020-11-09T08:00:00Z" class="datetime">9.11.2020</time>

         <h3>KÄÄPÄ Biotech signs a distribution agreement with Nutralliance to North America </h3>
      </div>
    </div>
  </article>
</a></div>
    <div class="views-row">
<a href="media/blog/sustainability-and-kaapa-forest-chaga-cultivation-network.html">
  <article data-history-node-id="44" about="/media/blog/sustainability-and-kaapa-forest-chaga-cultivation-network" typeof="schema:Article" class="node node--type-article-highlight bg-1a363e" style="background-image: linear-gradient(180deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0) 55%, #1a363e 75%), url(sites/default/files/styles/media_highlight/public/2021-07/pelkka-koivikko-pieni.jpg%3Fitok=iH25a-Ke); background-color: #1a363e">
    <div class="metadata-container">
      <div class="metadata">
        
            <div class="field field--name-field-article-type field--type-list-string field--label-hidden field__item">Blog</div>
       | <time datetime="2020-10-27T10:52:05Z" class="datetime">27.10.2020</time>

         <h3>Sustainability and KÄÄPÄ Forest chaga cultivation network</h3>
      </div>
    </div>
  </article>
</a></div>
    <div class="views-row">
<a href="media/news/inoculating-tree-seedlings-mycelium-accelerates-their-growth.html">
  <article data-history-node-id="46" about="/media/news/inoculating-tree-seedlings-mycelium-accelerates-their-growth" typeof="schema:Article" class="node node--type-article-highlight bg-1a363e" style="background-image: linear-gradient(180deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0) 55%, #1a363e 75%), url(sites/default/files/styles/media_highlight/public/2021-07/mycelium_background.jpg%3Fitok=aZr13lS8); background-color: #1a363e">
    <div class="metadata-container">
      <div class="metadata">
        
            <div class="field field--name-field-article-type field--type-list-string field--label-hidden field__item">News</div>
       | <time datetime="2020-03-20T20:21:10Z" class="datetime">20.3.2020</time>

         <h3>Inoculating tree seedlings with mycelium accelerates their growth</h3>
      </div>
    </div>
  </article>
</a></div>

    </div>
  
          </div>
</div>

  </div>

  </div>

    </div>
    
    
  </main>
  
  
  

  <?php	include "footer.php"; //--footer content  

?>
  