<?php                  
    $title_text = array();       
    $introduction_text = array();
    $body_text = array();
    $link = array();
    
    $title_text[0] = "Côte de Zűr Közösségi Kávézó";       
    $introduction_text[0] = "Coffee Shop";
    $body_text[0] = "kávézonk megfelelő hely beszélgetésekhez, vacsorához vagy koktélokhoz. A Tarnabod központjában található kávézó kedvességgel, udvariassággal és stílussal fogja meglepni. J'adore le café de cette bistrot.";
    $link[0] = "";  
    
    $title_text[1] = "Côte de Zűr Közösségi Kávézó";       
    $introduction_text[1] = "Coffee Shop";
    $body_text[1] = "kávézonk megfelelő hely beszélgetésekhez, vacsorához vagy koktélokhoz. A Tarnabod központjában található kávézó kedvességgel, udvariassággal és stílussal fogja meglepni.";
    $link[1] = ""; 
    
    $title_text[2] = "Côte de Zűr Közösségi Kávézó";       
    $introduction_text[2] = "Coffee Shop";
    $body_text[2] = "kávézonk megfelelő hely beszélgetésekhez, vacsorához vagy koktélokhoz. A Tarnabod központjában található kávézó kedvességgel, udvariassággal és stílussal fogja meglepni.";
    $link[2] = ""; 
?>
