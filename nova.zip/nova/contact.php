

<?php	include "header.php"; //--header content  

?>





  <main role="main">
    <a id="main-content" tabindex="-1"></a>
    <div class="layout-content">
        <div class="region region-content">
    <div id="block-kb2020-page-title" class="block block-core block-page-title-block">
  
    
      
  <h1 class="page-title"><span property="schema:name" class="field field--name-title field--type-string field--label-hidden">Contact</span>
</h1>


  </div>
<div class="views-element-container block block-views block-views-blockpersons-block-our-team" id="block-kb2020-views-block-persons-block-our-team">
  
    
      <div><div class="view view-persons view-id-persons view-display-id-block_our_team js-view-dom-id-6e65d9b8945d5aa25cfe338179caf093cd631e3b1ee48a7639e3b639647b0f51">
  
    
      
      <div class="view-content">
        <h3>Management &amp; Business Administration</h3>
   
  <h3>Marketing &amp; Communications</h3>
   
  <h3>Research &amp; Development</h3>
   

    </div>
  
          </div>
</div>

  </div>
<div id="block-kb2020-content" class="block block-system block-system-main-block">
  
    


      
<article data-history-node-id="9" about="/contact" typeof="schema:WebPage" class="node node--type-page">
  <div>
    
  </div>
</article>
  </div>
<div id="block-kb2020-webform" class="block block-webform block-webform-block">
  
      <h2>Contact us</h2>
    
      <form class="webform-submission-form webform-submission-add-form webform-submission-contact-form webform-submission-contact-add-form webform-submission-contact-node-9-form webform-submission-contact-node-9-add-form js-webform-details-toggle webform-details-toggle" data-drupal-selector="webform-submission-contact-node-9-add-form" action="contact.html" method="post" id="webform-submission-contact-node-9-add-form" accept-charset="UTF-8">
  
  <div class="js-form-item form-item js-form-type-textfield form-type-textfield js-form-item-name form-item-name">
      <label for="edit-name" class="js-form-required form-required">Name</label>
        <input data-drupal-selector="edit-name" type="text" id="edit-name" name="name" value="" size="60" maxlength="255" class="form-text required" required="required" aria-required="true" />

        </div>
<div class="js-form-item form-item js-form-type-email form-type-email js-form-item-email form-item-email">
      <label for="edit-email" class="js-form-required form-required">Email address</label>
        <input data-drupal-selector="edit-email" type="email" id="edit-email" name="email" value="" size="60" maxlength="254" class="form-email required" required="required" aria-required="true" />

        </div>
<div class="js-form-item form-item js-form-type-textfield form-type-textfield js-form-item-subject form-item-subject">
      <label for="edit-subject" class="js-form-required form-required">Subject</label>
        <input data-drupal-selector="edit-subject" type="text" id="edit-subject" name="subject" value="" size="60" maxlength="255" class="form-text required" required="required" aria-required="true" />

        </div>
<div class="js-form-item form-item js-form-type-textarea form-type-textarea js-form-item-message form-item-message">
      <label for="edit-message" class="js-form-required form-required">Message</label>
        <div class="form-textarea-wrapper">
  <textarea data-drupal-selector="edit-message" id="edit-message" name="message" rows="5" cols="60" class="form-textarea required resize-vertical" required="required" aria-required="true"></textarea>
</div>

        </div>
<div id="edit-markup" class="js-form-item form-item js-form-type-webform-markup form-type-webform-markup js-form-item-markup form-item-markup form-no-label">
        By sending a message, you accept our <a href="privacy-policy.html" target="_blank">privacy policy practices</a>
        </div>
<div data-drupal-selector="edit-actions" class="form-actions webform-actions js-form-wrapper form-wrapper" id="edit-actions"><input class="webform-button--submit button button--primary js-form-submit form-submit" data-drupal-selector="edit-actions-submit" type="submit" id="edit-actions-submit" name="op" value="Send message" />

</div>
<input autocomplete="off" data-drupal-selector="form-udkt6udsejwxgtvg-3fmtfpwdhimkjawtvzulxa5c-s" type="hidden" name="form_build_id" value="form-udkT6udsEJWXgTvG-3fmTfpWdHiMKJAwtvzulxA5c-s" />
<input data-drupal-selector="edit-webform-submission-contact-node-9-add-form" type="hidden" name="form_id" value="webform_submission_contact_node_9_add_form" />


                    <fieldset  data-drupal-selector="edit-captcha" class="captcha captcha-type-challenge--recaptcha">
          <legend class="captcha__title js-form-required form-required">
            CAPTCHA
          </legend>
                  <div class="captcha__element">
            <input data-drupal-selector="edit-captcha-sid" type="hidden" name="captcha_sid" value="135" />
<input data-drupal-selector="edit-captcha-token" type="hidden" name="captcha_token" value="XVCgGrAFDaBcBOPGRA2eyspZXYJSe45HAnR7x8YhpAk" />
<input data-drupal-selector="edit-captcha-response" type="hidden" name="captcha_response" value="Google no captcha" />
<div class="g-recaptcha" data-sitekey="6LfSQWobAAAAAE92xx9zVqWNVF32WMQkxFqKWNJ2" data-theme="light" data-type="image"></div><input data-drupal-selector="edit-captcha-cacheable" type="hidden" name="captcha_cacheable" value="1" />

          </div>
                          </fieldset>
            

  
</form>

  </div>



<h1>Kapcsolat</h1>
                <h2>Email:</h2>
                <p><a href="mailto:info@glia.hu">info@glia.hu</a>  </p>
                <h2>Cím:</h2>
                <p>1045 Budapest, Berlini út 47-49.</p>
                <iframe class="map" title="map" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d703.2198508713658!2d19.09947231391585!3d47.55008544870454!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4741dda1bffd37af%3A0x6fc961bdb07f8b2c!2sGLIA%20kft.!5e0!3m2!1sen!2suk!4v1634130796014!5m2!1sen!2suk" allowfullscreen="" loading="lazy"></iframe>
                


  <?php	include "footer.php"; //--footer content  

?>